package com.familyguard

import kotlin.random.Random

class Q(val q: String, val o: List<String>, val a: Int)
class Sub(val name: String, val ar: Boolean, val bank: () -> List<Q>)

// each line: question|correct|wrong|wrong  (options are shuffled when the quiz starts)
private fun mk(s: String) = s.trim().lines().map { val p = it.split("|"); val o = p.drop(1).shuffled(); Q(p[0], o, o.indexOf(p[1])) }

private fun mathQ() = List(10) { i ->
    val x = Random.nextInt(2, 13); val y = Random.nextInt(2, 13)
    val (q, a) = if (i < 5) "$x × $y = ?" to x * y else "${x * y} ÷ $y = ?" to x
    val w = mutableSetOf<Int>()
    while (w.size < 2) { val d = a + Random.nextInt(-4, 5); if (d != a && d > 0) w += d }
    val o = (listOf(a) + w).shuffled(); Q(q, o.map { it.toString() }, o.indexOf(a))
}

val SUBJECTS = listOf(
    Sub("English", false) { mk("""
Which spelling is correct?|Receive|Recieve|Receeve
Which spelling is correct?|Definitely|Definately|Definitly
Which spelling is correct?|Necessary|Neccessary|Necesary
She ___ to school every day.|goes|go|going
They ___ playing football now.|are|is|am
What is the plural of "child"?|children|childs|childrens
Sara has a red kite. She flies it in the park. What colour is the kite?|Red|Blue|Green
Sara has a red kite. She flies it in the park. Where does she fly it?|In the park|At school|At the beach
Tom was tired, so he went to bed early. Why did Tom go to bed?|He was tired|He was hungry|He was happy
What is the past tense of "run"?|ran|runned|running""") },
    Sub("Science", false) { mk("""
Which organ pumps blood around the body?|Heart|Lungs|Liver
How many bones does an adult human have?|206|300|100
Which organs do we breathe with?|Lungs|Stomach|Kidneys
What is the largest organ of the body?|Skin|Heart|Brain
Which organ controls our thinking?|Brain|Heart|Liver
Which sense do we use our nose for?|Smell|Taste|Hearing
Which vessels carry blood away from the heart?|Arteries|Nerves|Muscles
What do our teeth help us do?|Chew food|See|Hear
Where is most food digested?|Stomach|Ears|Knee
How many senses do humans have?|5|3|8""") },
    Sub("Math", false) { mathQ() },
    Sub("العربية", true) { mk("""
الفاعل في جملة «كتب الطالبُ الدرسَ» هو:|الطالبُ|الدرسَ|كتب
المفعول به في جملة «قرأ عليٌّ القصةَ» هو:|القصةَ|عليٌّ|قرأ
الفاعل يكون دائمًا:|مرفوعًا|منصوبًا|مجرورًا
المفعول به يكون:|منصوبًا|مرفوعًا|مجرورًا
الاسم بعد حرف الجر يكون:|مجرورًا|مرفوعًا|منصوبًا
أيُّ الكلمات التالية فعل؟|يلعبُ|مدرسة|حديقة
أيُّ الكلمات التالية حرف؟|في|كتاب|ذهبَ
الجملة الاسمية تبدأ بـ:|اسم|فعل|حرف جر
الجملة الفعلية تبدأ بـ:|فعل|اسم|حرف
في جملة «محمدٌ مجتهدٌ» كلمة «مجتهدٌ» تُعرب:|خبرًا|فاعلًا|مفعولًا به""") },
    Sub("التربية الإسلامية", true) { mk("""
كم عدد آيات سورة الفاتحة؟|٧|٥|٩
أكمل: ﴿الْحَمْدُ لِلَّهِ رَبِّ ...﴾|الْعَالَمِينَ|النَّاسِ|الْمُؤْمِنِينَ
أكمل: ﴿الرَّحْمَٰنِ ...﴾|الرَّحِيمِ|الْكَرِيمِ|الْعَظِيمِ
أكمل: ﴿مَالِكِ يَوْمِ ...﴾|الدِّينِ|الْحِسَابِ|الْقِيَامَةِ
أكمل: ﴿إِيَّاكَ نَعْبُدُ وَإِيَّاكَ ...﴾|نَسْتَعِينُ|نَسْتَغْفِرُ|نَحْمَدُ
أكمل: ﴿اهْدِنَا الصِّرَاطَ ...﴾|الْمُسْتَقِيمَ|الْقَوِيمَ|الْوَاسِعَ
من أسماء سورة الفاتحة:|أم الكتاب|الكوثر|الإخلاص
نقرأ سورة الفاتحة في كل:|ركعة من الصلاة|وضوء|وجبة
معنى «الْحَمْدُ» هو:|الشكر والثناء|الخوف|النوم
أكمل: ﴿غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا ...﴾|الضَّالِّينَ|الْمُؤْمِنِينَ|الصَّالِحِينَ""") },
    Sub("التربية الوطنية", true) { mk("""
ما عاصمة دولة الإمارات العربية المتحدة؟|أبوظبي|دبي|الشارقة
كم عدد الإمارات في الدولة؟|٧|٥|٩
من هو مؤسس دولة الإمارات؟|الشيخ زايد بن سلطان|الشيخ حمدان|الشيخ سلطان
متى اليوم الوطني لدولة الإمارات؟|٢ ديسمبر|١ يناير|١٥ مايو
ما عملة دولة الإمارات؟|الدرهم|الريال|الدينار
ما اللغة الرسمية للدولة؟|العربية|الإنجليزية|الفرنسية
أكبر إمارة من حيث المساحة هي:|أبوظبي|عجمان|الفجيرة
ألوان علم الإمارات هي:|أحمر وأخضر وأبيض وأسود|أزرق وأصفر|وردي وبنفسجي
في أي إمارة يقع برج خليفة؟|دبي|رأس الخيمة|أم القيوين
مدينة العين تقع في إمارة:|أبوظبي|دبي|الشارقة""") }
)
