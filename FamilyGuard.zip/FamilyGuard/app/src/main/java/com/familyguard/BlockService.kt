package com.familyguard

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/** Watches which app is on screen and sends the child Home if it is blocked, locked or over its limit. */
class BlockService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() { check(rootInActiveWindow?.packageName?.toString()); h.postDelayed(this, 10000) }
    }
    override fun onServiceConnected() { Store.init(this); h.post(loop) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) check(e.packageName?.toString())
    }
    override fun onInterrupt() {}
    override fun onDestroy() { h.removeCallbacks(loop); super.onDestroy() }

    private fun check(pkg: String?) {
        if (pkg == null || pkg == packageName) return
        Store.init(this)
        if (scan(this).none { it.first == pkg }) return   // never touches the launcher or system UI
        val lim = Store.limit(pkg)
        val over = lim > 0 && (usage(this)[pkg] ?: 0L) >= (lim + Store.bonus).toLong()
        if (Store.locked || Store.blocked(pkg) || over) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            val why = if (Store.locked) "Device is locked" else if (over) "Time limit reached" else "App is blocked"
            Toast.makeText(this, "$why 🔒", Toast.LENGTH_SHORT).show()
        }
    }
}
