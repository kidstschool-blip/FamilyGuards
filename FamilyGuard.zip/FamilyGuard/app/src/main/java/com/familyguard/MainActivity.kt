package com.familyguard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); Store.init(this)
        setContent { MaterialTheme { App() } }
    }
}

@Composable fun Pin(v: String, on: (String) -> Unit, label: String = "PIN") =
    OutlinedTextField(v, { if (it.length <= 4) on(it) }, label = { Text(label) }, singleLine = true,
        visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))

@Composable fun H(t: String) = Text(t, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(bottom = 12.dp))

@Composable fun App() {
    var tab by remember { mutableIntStateOf(0) }
    var rev by remember { mutableIntStateOf(0) }
    val names = listOf("Home", "Login", "Controls", "Quiz Time"); val icons = listOf("🏠", "🔑", "🛡️", "🧠")
    Scaffold(bottomBar = { NavigationBar { names.forEachIndexed { i, n ->
        NavigationBarItem(tab == i, { tab = i; rev++; if (i != 2) Session.open = false }, { Text(icons[i]) }, label = { Text(n) }) } } }) { p ->
        Box(Modifier.padding(p).padding(16.dp)) {
            key(rev) { when (tab) { 0 -> Home(); 1 -> Login(); 2 -> Controls(); else -> QuizTab() } }
        }
    }
}

@Composable fun Home() {
    val c = LocalContext.current
    val apps = remember { scan(c) }; val use = remember { usage(c) }
    var locked by remember { mutableStateOf(Store.locked) }; var pin by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        H("Home")
        if (!hasUsage(c)) Text("⚠️ Usage access is off. Enable it in the Login tab to see real play time.", color = MaterialTheme.colorScheme.error)
        val total = apps.sumOf { use[it.first] ?: 0L }
        Text("Play time today: ${total / 60}h ${total % 60}m", style = MaterialTheme.typography.titleLarge)
        Text("Games / apps played:", Modifier.padding(top = 12.dp))
        apps.filter { (use[it.first] ?: 0L) > 0 }.sortedByDescending { use[it.first] }.forEach {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(it.second, Modifier.weight(1f)); Text("${use[it.first]} min") } }
        Spacer(Modifier.height(16.dp))
        Text(if (locked) "🔒 Device is locked" else "🔓 Device is unlocked", style = MaterialTheme.typography.titleMedium)
        if (locked) { Pin(pin, { pin = it }); Button({ if (pinOK(pin)) { Store.locked = false; locked = false; pin = ""; msg = "" } else msg = "Wrong PIN" }) { Text("Unlock device") } }
        else Button({ Store.locked = true; locked = true }) { Text("Lock child's device") }
        if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error)
    }
}

@Composable fun Login() {
    val c = LocalContext.current
    var em by remember { mutableStateOf(Store.email) }; var pin by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    val first = Store.pin.isEmpty()
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        H(if (first) "Create parent PIN" else "Parent sign in")
        OutlinedTextField(em, { em = it }, label = { Text("Child's email") }, singleLine = true)
        Pin(pin, { pin = it }, if (first) "Choose a 4-digit PIN" else "Enter PIN")
        Button({
            if (first) { if (pin.length == 4) { Store.pin = pin; Store.email = em; Session.open = true; msg = "Saved. Controls are now PIN-locked." } else msg = "PIN must be 4 digits." }
            else if (pinOK(pin)) { Store.email = em; Session.open = true; msg = "Signed in." } else msg = "Wrong PIN."
        }) { Text(if (first) "Create account" else "Sign in") }
        if (msg.isNotEmpty()) Text(msg)
        HorizontalDivider()
        Text("Permissions (needed for real scanning and blocking)", style = MaterialTheme.typography.titleMedium)
        Text(if (hasUsage(c)) "✔ Usage access granted" else "✘ Usage access missing")
        Button({ c.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }) { Text("Grant usage access") }
        Button({ c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Turn on Family Guard blocker") }
        Text("In Accessibility settings, open Installed apps → Family Guard and switch it on.")
    }
}

@Composable fun Controls() {
    val c = LocalContext.current
    var pin by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    var apps by remember { mutableStateOf(scan(c)) }
    if (Store.pin.isEmpty()) { Text("Create your PIN in the Login tab first."); return }
    if (!Session.open) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            H("Controls 🔒"); Pin(pin, { pin = it })
            Button({ if (pinOK(pin)) Session.open = true else msg = "Wrong PIN" }) { Text("Open controls") }
            Text(msg, color = MaterialTheme.colorScheme.error)
        }; return
    }
    val use = remember { usage(c) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { H("Controls"); Text("${apps.size} apps found on this device"); Button({ apps = scan(c) }) { Text("🔍 Scan device again") } }
        items(apps) { (pkg, name) ->
            var lim by remember(pkg) { mutableStateOf(Store.limit(pkg).let { if (it == 0) "" else "$it" }) }
            var blk by remember(pkg) { mutableStateOf(Store.blocked(pkg)) }
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
                Text(name, style = MaterialTheme.typography.titleMedium)
                Text("Today: ${use[pkg] ?: 0} min", style = MaterialTheme.typography.bodySmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(lim, { v -> lim = v.filter { it.isDigit() }.take(3); Store.setLimit(pkg, lim.toIntOrNull() ?: 0) },
                        label = { Text("Limit (min)") }, singleLine = true, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    Spacer(Modifier.width(12.dp)); Text("Close / block"); Switch(blk, { blk = it; Store.setBlocked(pkg, it) })
                }
            } }
        }
        item { Button({ Session.open = false; pin = "" }) { Text("🔒 Lock controls") } }
    }
}

@Composable fun QuizTab() {
    var sub by remember { mutableStateOf<Sub?>(null) }; var qs by remember { mutableStateOf(listOf<Q>()) }
    var i by remember { mutableIntStateOf(0) }; var score by remember { mutableIntStateOf(0) }; var pick by remember { mutableIntStateOf(-1) }
    var done by remember { mutableStateOf(false) }; var pts by remember { mutableIntStateOf(Store.pts) }
    var pin by remember { mutableStateOf("") }; var amt by remember { mutableStateOf("5") }; var msg by remember { mutableStateOf("") }
    fun start(s: Sub) { sub = s; qs = s.bank(); i = 0; score = 0; pick = -1; done = false }
    val s = sub
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (s == null) {
            H("Quiz Time"); Text("⭐ Points: $pts", style = MaterialTheme.typography.titleLarge)
            Button({ if (pts >= 10) { pts -= 10; Store.pts = pts; Store.bonus += 10; msg = "+10 bonus minutes added to every limit." } }, enabled = pts >= 10) { Text("Use 10 points → +10 min play") }
            Text("Choose a subject (10 questions, +10 points)")
            SUBJECTS.forEach { Button({ start(it) }, Modifier.fillMaxWidth()) { Text(it.name) } }
            HorizontalDivider(); Text("Parent: deduct points", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Pin(pin, { pin = it }, "PIN"); OutlinedTextField(amt, { amt = it.filter(Char::isDigit) }, label = { Text("Pts") }, modifier = Modifier.width(80.dp), singleLine = true)
            }
            Button({ if (pinOK(pin)) { pts = maxOf(0, pts - (amt.toIntOrNull() ?: 0)); Store.pts = pts; msg = "Points deducted." } else msg = "Wrong PIN" }) { Text("Deduct") }
            if (msg.isNotEmpty()) Text(msg)
        } else if (done) {
            val fail = 10 - score >= 5
            H("$score / 10")
            Text(if (fail) "😕 ${10 - score} mistakes. Try again! You got 0 points." else "🎉 Well done! You earned +10 points.", style = MaterialTheme.typography.titleMedium)
            Button({ start(s) }) { Text("Try again") }; Button({ sub = null }) { Text("Subjects") }
        } else {
            val q = qs[i]
            CompositionLocalProvider(LocalLayoutDirection provides if (s.ar) LayoutDirection.Rtl else LayoutDirection.Ltr) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${s.name} · ${i + 1}/10"); Text(q.q, style = MaterialTheme.typography.titleLarge)
                    q.o.forEachIndexed { j, o ->
                        val col = if (pick < 0) ButtonDefaults.buttonColors() else if (j == q.a) ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFF1F9D57))
                            else if (j == pick) ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFFD64545)) else ButtonDefaults.buttonColors()
                        Button({ if (pick < 0) { pick = j; if (j == q.a) score++ } }, Modifier.fillMaxWidth(), colors = col) { Text(o) }
                    }
                    if (pick >= 0) Button({ if (i < 9) { i++; pick = -1 } else { done = true; if (10 - score < 5) { pts += 10; Store.pts = pts } } }) { Text(if (i < 9) "Next" else "Finish") }
                }
            }
        }
    }
}
