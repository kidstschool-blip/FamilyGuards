package com.familyguard

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.compose.runtime.*
import java.util.Calendar

object Store {
    lateinit var p: SharedPreferences
    fun init(c: Context) { p = c.getSharedPreferences("fg", 0) }
    var pin: String get() = p.getString("pin", "")!!; set(v) { p.edit().putString("pin", v).apply() }
    var email: String get() = p.getString("email", "")!!; set(v) { p.edit().putString("email", v).apply() }
    var pts: Int get() = p.getInt("pts", 0); set(v) { p.edit().putInt("pts", v).apply() }
    var bonus: Int get() = p.getInt("bonus", 0); set(v) { p.edit().putInt("bonus", v).apply() }
    var locked: Boolean get() = p.getBoolean("locked", false); set(v) { p.edit().putBoolean("locked", v).apply() }
    fun limit(pkg: String) = p.getInt("lim_$pkg", 0)
    fun setLimit(pkg: String, m: Int) = p.edit().putInt("lim_$pkg", m).apply()
    fun blocked(pkg: String) = p.getBoolean("blk_$pkg", false)
    fun setBlocked(pkg: String, b: Boolean) = p.edit().putBoolean("blk_$pkg", b).apply()
}

object Session { var open by mutableStateOf(false) }

fun pinOK(s: String) = Store.pin.isNotEmpty() && s == Store.pin

/** REAL scan: every app on the device that has a launcher icon (package, name). */
fun scan(c: Context): List<Pair<String, String>> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
        .filter { it.first != c.packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
}

fun hasUsage(c: Context): Boolean {
    val a = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
}

/** REAL minutes each app was in the foreground today. */
fun usage(c: Context): Map<String, Long> {
    val u = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val s = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
    return u.queryAndAggregateUsageStats(s, System.currentTimeMillis()).mapValues { it.value.totalTimeInForeground / 60000 }
}
